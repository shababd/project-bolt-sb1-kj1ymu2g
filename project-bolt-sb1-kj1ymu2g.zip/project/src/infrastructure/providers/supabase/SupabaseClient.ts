// src/infrastructure/providers/supabase/SupabaseClient.ts
// src/infrastructure/providers/supabase/SupabaseClient.ts

import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Supabase URL and Anon Key must be defined in your .env.local file');
}

// هذا هو المتغير 'supabase' الذي يستورده ملفك المُعدّل
export const supabase = createClient(supabaseUrl, supabaseAnonKey);
